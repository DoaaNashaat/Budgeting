﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using Budgeting.Models;

namespace Budgeting.Controllers
{
    public class BudgetElementsController : Controller
    {
        private BudgetingEntities1 db = new BudgetingEntities1();

        // GET: BudgetElements
        public ActionResult Index()
        {
            TempData.Keep("UserId");
            return View(db.BudgetElements.ToList());
        }

        // GET: BudgetElements/Details/5
        public ActionResult Details(int? id)
        {
            TempData.Keep("UserId");
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            BudgetElement budgetElement = db.BudgetElements.Find(id);
            if (budgetElement == null)
            {
                return HttpNotFound();
            }
            return View(budgetElement);
        }

        // GET: BudgetElements/Create
        public ActionResult Create()
        {
            TempData.Keep("UserId");
            return View();
        }

        // POST: BudgetElements/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "BudgetElementId,Name,IsFixed")] BudgetElement budgetElement)
        {
            TempData.Keep("UserId");
            if (ModelState.IsValid)
            {
                db.BudgetElements.Add(budgetElement);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(budgetElement);
        }

        // GET: BudgetElements/Edit/5
        public ActionResult Edit(int? id)
        {
            TempData.Keep("UserId");
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            BudgetElement budgetElement = db.BudgetElements.Find(id);
            if (budgetElement == null)
            {
                return HttpNotFound();
            }
            return View(budgetElement);
        }

        // POST: BudgetElements/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "BudgetElementId,Name,IsFixed")] BudgetElement budgetElement)
        {
            TempData.Keep("UserId");
            if (ModelState.IsValid)
            {
                db.Entry(budgetElement).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(budgetElement);
        }

        // GET: BudgetElements/Delete/5
        public ActionResult Delete(int? id)
        {
            TempData.Keep("UserId");
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            BudgetElement budgetElement = db.BudgetElements.Find(id);
            if (budgetElement == null)
            {
                return HttpNotFound();
            }
            return View(budgetElement);
        }

        // POST: BudgetElements/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            TempData.Keep("UserId");
            BudgetElement budgetElement = db.BudgetElements.Find(id);
            db.BudgetElements.Remove(budgetElement);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
