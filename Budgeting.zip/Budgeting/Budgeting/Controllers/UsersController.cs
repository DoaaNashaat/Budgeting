﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using Budgeting.Models;

namespace Budgeting.Controllers
{
    public class UsersController : Controller
    {
        private BudgetingEntities1 db = new BudgetingEntities1();


        // GET: Users/Create
        public ActionResult Login()
        {
           
            return View();
        }

        // POST: Users/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Login([Bind(Include = "Username,Password")] User user)
        {
            if (ModelState.IsValid)
            {
                User us =  db.Users.Where(u=> u.Username == user.Username & u.Password==user.Password).FirstOrDefault();
                if (us != null)
                {
                    TempData["UserId"] = us.UserId;
                    TempData.Keep("UserId");
                    return RedirectToAction("Index","Budgets");
                }
              
                return RedirectToAction("Index");
            }

            ViewBag.RoleId = new SelectList(db.UserRoles, "RoleId", "RoleName", user.RoleId);
            return View(user);
        }

        public ActionResult Logout()
        {
            TempData["UserId"] = null;
            return RedirectToAction("Login", "Users");
        }
    }
}
