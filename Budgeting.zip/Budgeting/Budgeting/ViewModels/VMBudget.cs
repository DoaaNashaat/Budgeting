﻿using Budgeting.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Budgeting.ViewModels
{
    public class VMBudget
    {
        public int BudgetId { get; set; }

        [Required]
        [Display(Name = "Budget Element")]
        public Nullable<int> BudgetElementId { get; set; }

        [Display(Name = "Budget Element")]
        public string BudgetElementNAme { get; set; }

      
        public Nullable<int> BudgetAuditStatusId { get; set; }
        public Nullable<int> UserId { get; set; }
        public Nullable<decimal> Value { get; set; }
        public string Comments { get; set; }
        public string FilePath { get; set; }

        public virtual BudgetAuditStatu BudgetAuditStatu { get; set; }
        public virtual BudgetElement BudgetElement { get; set; }
        public virtual User User { get; set; }
    }
}