﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BudgetingDAL;

namespace BudgetingBLL
{
   public class BudgetBLL
    {

        #region BLL Methods Implementation

        public static int Add(Budget pBudget)
        {
            using (BudgetingEntities dbbudgetContext = new BudgetingEntities())
            {
                dbbudgetContext.Budgets.Add(pBudget);
                return dbbudgetContext.SaveChanges();
            }

        }

        public static int Update(BudgetingDAL.BudgetElement pBudget)
        {
            using (BudgetingEntities dbbudgetContext = new BudgetingEntities())
            {
                dbbudgetContext.Entry(pBudget).State = EntityState.Modified;
                return dbbudgetContext.SaveChanges();
            }
        }

        public static int Delete(Budget pBudget)
        {
            using (BudgetingEntities dbbudgetContext = new BudgetingEntities())
            {
                dbbudgetContext.Budgets.Remove(pBudget);
                return dbbudgetContext.SaveChanges();
            }
        }

        public static int Delete(int pID)
        {
            using (BudgetingEntities dbbudgetContext = new BudgetingEntities())
            {
                Budget _BudgetElement = dbbudgetContext.Budgets.Find(pID);
                dbbudgetContext.Budgets.Remove(_BudgetElement);
                return dbbudgetContext.SaveChanges();
            }
        }

     
        public static Budget GetBudgetElementID(int pID)
        {
            using (BudgetingEntities dbbudgetContext = new BudgetingEntities())
            {
                return dbbudgetContext.Budgets.Find(pID);
            }
        }

        /// <summary>
        /// get All Hospital Object
        /// </summary>
        /// <returns></returns>
        public static IList<Budget> GetAllBudgetElements()
        {
            using (BudgetingEntities dbbudgetContext = new BudgetingEntities())
            {
                return dbbudgetContext.Budgets.ToList();
            }
        }

      

        #endregion
    }
}
