﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BudgetingDAL;

namespace BudgetingBLL
{
   public class BudgetElementsBLL
    {

        #region BLL Methods Implementation

        public static int Add(BudgetingDAL.BudgetElement pBudgetElements)
        {
            using (BudgetingEntities dbbudgetContext = new BudgetingEntities())
            {
                dbbudgetContext.BudgetElements.Add(pBudgetElements);
                return dbbudgetContext.SaveChanges();
            }

        }

        public static int Update(BudgetingDAL.BudgetElement pBudgetElements)
        {
            using (BudgetingEntities dbbudgetContext = new BudgetingEntities())
            {
                dbbudgetContext.Entry(pBudgetElements).State = EntityState.Modified;
                return dbbudgetContext.SaveChanges();
            }
        }

        public static int Delete(BudgetingDAL.BudgetElement pBudgetElements)
        {
            using (BudgetingEntities dbbudgetContext = new BudgetingEntities())
            {
                dbbudgetContext.BudgetElements.Remove(pBudgetElements);
                return dbbudgetContext.SaveChanges();
            }
        }

        public static int Delete(int pID)
        {
            using (BudgetingEntities dbbudgetContext = new BudgetingEntities())
            {
                BudgetElement _BudgetElement = dbbudgetContext.BudgetElements.Find(pID);
                dbbudgetContext.BudgetElements.Remove(_BudgetElement);
                return dbbudgetContext.SaveChanges();
            }
        }

     
        public static BudgetElement GetBudgetElementID(int pID)
        {
            using (BudgetingEntities dbbudgetContext = new BudgetingEntities())
            {
                return dbbudgetContext.BudgetElements.Find(pID);
            }
        }

        /// <summary>
        /// get All Hospital Object
        /// </summary>
        /// <returns></returns>
        public static IList<BudgetElement> GetAllBudgetElements()
        {
            using (BudgetingEntities dbbudgetContext = new BudgetingEntities())
            {
                return dbbudgetContext.BudgetElements.ToList();
            }
        }

      

        #endregion
    }
}
