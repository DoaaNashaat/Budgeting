﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BudgetingBLL.Models
{
    using BudgetingDAL;
    using System;
    using System.Collections.Generic;

    public partial class BudgetElement
    {
     
        public int BudgetElementId { get; set; }
        public string Name { get; set; }
        public Nullable<bool> IsFixed { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Budget> Budgets { get; set; }
    }
}
