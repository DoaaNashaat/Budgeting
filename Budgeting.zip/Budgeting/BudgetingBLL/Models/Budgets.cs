﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BudgetingBLL.Models
{
    using BudgetingDAL;
    using System;
    using System.Collections.Generic;

    public partial class Budgets
    {


        public int BudgetId { get; set; }
        public Nullable<int> BudgetElementId { get; set; }
        public Nullable<int> BudgetAuditStatusId { get; set; }
        public Nullable<int> UserId { get; set; }
        public Nullable<decimal> Value { get; set; }
        public string Comments { get; set; }
        public string FilePath { get; set; }

        public virtual BudgetAuditStatu BudgetAuditStatu { get; set; }
        public virtual BudgetElement BudgetElement { get; set; }
        public virtual User User { get; set; }
    }
}
